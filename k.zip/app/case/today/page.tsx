"use client";

import { useEffect, useState } from "react";
import DailyCasePlayer from "./DailyCasePlayer";
import { ensureDailyCaseSchedule, getDailyCase, getTehranDateKey, readDailyCaseSchedule } from "../../../lib/dailyCase";

export default function DailyCasePage() {
  const [schedule, setSchedule] = useState<Record<string, string> | null>(null);
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    const current = new Date();
    setNow(current);
    setSchedule(ensureDailyCaseSchedule(30, current));

    const refresh = () => setSchedule(readDailyCaseSchedule());
    window.addEventListener("storage", refresh);
    window.addEventListener("sonic:daily-case-schedule-updated", refresh);
    return () => {
      window.removeEventListener("storage", refresh);
      window.removeEventListener("sonic:daily-case-schedule-updated", refresh);
    };
  }, []);

  if (!now || !schedule) {
    return (
      <main dir="rtl" className="min-h-screen bg-[#fbfaf8] px-5 py-10">
        <div className="mx-auto max-w-[820px]">
          <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center shadow-[0_8px_28px_rgba(15,23,42,0.05)]">
            <div className="mx-auto h-12 w-12 rounded-full bg-slate-100" />
            <div className="mx-auto mt-6 h-4 w-36 rounded bg-slate-100" />
            <div className="mx-auto mt-4 h-7 w-72 max-w-full rounded bg-slate-100" />
          </div>
        </div>
      </main>
    );
  }

  const caseData = getDailyCase(now, schedule);
  const dateKey = getTehranDateKey(now);

  return (
    <>
      <DailyCasePlayer caseData={caseData} dateKey={dateKey} />
    </>
  );
}
