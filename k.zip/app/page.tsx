"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import {
  getDailyCase,
  readDailyCaseSchedule,
} from "../lib/dailyCase";

/* =========================================================
   TYPES
========================================================= */

type DailyCase = ReturnType<typeof getDailyCase>;

type ContinueCaseData = {
  title: string;
  specialty: string;
  level: string;
  progress: string;
  percent: number;
  type: "lungs" | "kidney" | "heart";
};

/* =========================================================
   DATA
========================================================= */

const progress = [
  { title: "ریه", value: 60 },
  { title: "قلب", value: 40 },
  { title: "کلیه", value: 35 },
  { title: "گوارش", value: 20 },
];

const continueCases: ContinueCaseData[] = [
  {
    title: "بیماری‌های انسدادی ریه",
    specialty: "Pulmonology",
    level: "سطح متوسط",
    progress: "۴۰ از ۵۰",
    percent: 80,
    type: "lungs",
  },
  {
    title: "بیماری‌های گلومرولی",
    specialty: "Nephrology",
    level: "سطح سخت",
    progress: "۲۵ از ۳۰",
    percent: 83,
    type: "kidney",
  },
  {
    title: "نارسایی قلبی",
    specialty: "Cardiology",
    level: "سطح متوسط",
    progress: "۱۰ از ۱۵",
    percent: 67,
    type: "heart",
  },
];

/* =========================================================
   SPECIALTY PNGS
   IMPORTANT:
   Practice card uses PNG only.
========================================================= */

const practiceSpecialties = [
  {
    key: "pulmonology",
    label: "ریه",
    src: "/icons/courses/lungs.png",
  },
  {
    key: "cardiology",
    label: "قلب",
    src: "/icons/courses/heart.png",
  },
  {
    key: "nephrology",
    label: "کلیه",
    src: "/icons/courses/kidney.png",
  },
  {
    key: "gastroenterology",
    label: "گوارش",
    src: "/icons/courses/stomach.png",
  },
  {
    key: "neurology",
    label: "نورولوژی",
    src: "/icons/courses/brain.png",
  },
];

/* =========================================================
   HELPERS
========================================================= */

function courseLabel(course: string) {
  const labels: Record<string, string> = {
    pulmonology: "Pulmonology",
    cardiology: "Cardiology",
    nephrology: "Nephrology",
    gastroenterology: "Gastroenterology",
    endocrinology: "Endocrinology",
    neurology: "Neurology",
    "hematology-oncology": "Hematology",
    "infectious-disease": "Infectious Disease",
  };

  return labels[course] ?? course;
}

function difficultyLabel(
  difficulty: string,
) {
  if (difficulty === "easy") return "آسان";
  if (difficulty === "medium") return "متوسط";
  return "سخت";
}

/* =========================================================
   PAGE
========================================================= */

export default function HomePage() {
  const router = useRouter();

  const [dailyCase, setDailyCase] =
    useState<DailyCase>(() =>
      getDailyCase(new Date()),
    );

  useEffect(() => {
    const refreshDailyCase = () => {
      const now = new Date();

      setDailyCase(
        getDailyCase(
          now,
          readDailyCaseSchedule(),
        ),
      );
    };

    refreshDailyCase();

    window.addEventListener(
      "storage",
      refreshDailyCase,
    );

    window.addEventListener(
      "sonic:daily-case-schedule-updated",
      refreshDailyCase,
    );

    return () => {
      window.removeEventListener(
        "storage",
        refreshDailyCase,
      );

      window.removeEventListener(
        "sonic:daily-case-schedule-updated",
        refreshDailyCase,
      );
    };
  }, []);

  const difficulty = difficultyLabel(
    dailyCase.difficulty,
  );

  const specialty = courseLabel(
    dailyCase.course,
  );

  return (
    <main
      dir="rtl"
      className="min-h-screen bg-[#fbfaf8] text-[#172033]"
    >
      <div className="mx-auto w-full max-w-[1180px] px-5 pb-14 pt-6 lg:px-8 lg:pt-7">

        {/* =================================================
            CASE OF THE DAY
            TEXT = RIGHT
            IMAGE = LEFT
        ================================================== */}

        <section
          dir="ltr"
          style={{
            fontFamily:
              "var(--font-vazirmatn), sans-serif",
          }}
          className="
            mx-auto
            w-full
            max-w-[1180px]
            overflow-hidden
            rounded-[18px]
            border
            border-[#e7e4de]
            bg-white
            shadow-[0_8px_30px_rgba(15,23,42,0.045)]
          "
        >
          <div className="grid h-[300px] md:grid-cols-[0.98fr_1.02fr]">

            {/* =================================================
                IMAGE / VISUAL — LEFT
            ================================================== */}

            <div
              dir="ltr"
              className="
                relative
                order-1
                h-full
                overflow-hidden
                bg-[#f4f5f2]
              "
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="mx-auto flex h-[62px] w-[62px] items-center justify-center rounded-full bg-white shadow-[0_4px_18px_rgba(20,45,66,0.06)]">
                    <StethoscopeIcon
                      size={28}
                      className="text-[#506a69]"
                    />
                  </div>

                  <div className="mt-3 text-[12px] text-[#89918e]">
                    کیس بالینی امروز
                  </div>
                </div>
              </div>

              <div className="absolute bottom-6 left-7 text-[10px] font-medium uppercase tracking-[0.18em] text-[#969b98]">
                SONIC
              </div>
            </div>

            {/* =================================================
                TEXT — RIGHT
            ================================================== */}

            <div
              dir="rtl"
              className="
                order-2
                flex
                h-full
                min-h-0
                flex-col
                justify-center
                overflow-hidden
                px-8
                py-5
                sm:px-10
                lg:px-11
              "
            >
              {/* 1 — CASE TODAY */}
              <div className="flex items-center gap-2">
                <span className="text-[15px] leading-none text-[#617c72]">
                  ●
                </span>

                <span className="text-[16px] font-semibold leading-5 text-[#111d28]">
                  کیس امروز
                </span>
              </div>

              {/* 2 — CHIEF COMPLAINT */}
              <h2
                className="
                  mt-2
                  max-w-[600px]
                  text-[27px]
                  font-semibold
                  leading-[1.28]
                  tracking-normal
                  text-[#173250]
                  sm:text-[29px]
                "
              >
                {dailyCase.presentation}
              </h2>

              {/* 3 — SHORT DESCRIPTION */}
              <p
                className="
                  mt-2
                  max-w-[560px]
                  text-[13px]
                  leading-5
                  text-[#607793]
                "
              >
                بیمار {dailyCase.patient.age} ساله با این شکایت مراجعه کرده است.
                کیس را از اولین قدم بررسی کن و به تشخیص برس.
              </p>

              {/* 4 — DIFFICULTY + COURSE */}
              <div className="mt-3 flex flex-wrap justify-start gap-2">
                <CaseBadge>
                  {difficulty}
                </CaseBadge>

                <CaseBadge>
                  {specialty}
                </CaseBadge>
              </div>

              {/* 5 — START CASE */}
              <button
                type="button"
                onClick={() =>
                  router.push("/case/today")
                }
                className="
                  mt-4
                  flex
                  h-[46px]
                  w-full
                  max-w-[235px]
                  items-center
                  justify-center
                  gap-3
                  rounded-[11px]
                  bg-[#294b45]
                  text-[13px]
                  font-medium
                  text-white
                  transition
                  hover:bg-[#213f3a]
                "
              >
                شروع کیس
                <ArrowLeftIcon size={17} />
              </button>
            </div>
          </div>
        </section>

        {/* =================================================
            PRACTICE MODES
            RIGHT → LEFT
        ================================================== */}

        <section className="mt-8">

          <div className="mb-4 text-right">
            <h2
              className="
                font-[var(--font-vazirmatn)]
                text-[24px]
                font-semibold
                tracking-[-0.025em]
                text-[#152b3c]
              "
            >
              انتخاب مسیر تمرین
            </h2>

            <p className="mt-1 text-[13px] text-[#87919a]">
              با توجه به هدف خود، مسیر مناسب را انتخاب کنید.
            </p>
          </div>

          <div
            dir="rtl"
            className="
              flex
              flex-col
              gap-4
              lg:flex-row
            "
          >

            {/* =================================================
                1 — PRACTICE
            ================================================== */}

            <Link
              href="/practice"
              className="
                group
                order-1
                relative
                min-h-[190px]
                flex-[2.15]
                overflow-hidden
                rounded-[15px]
                bg-[#294640]
                px-8
                py-7
                text-white
                shadow-[0_9px_28px_rgba(28,59,53,0.11)]
                transition
                hover:-translate-y-[2px]
                hover:shadow-[0_14px_32px_rgba(28,59,53,0.14)]
              "
            >
              <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.08]">
                <div className="absolute -left-14 top-4 h-[190px] w-[190px] rounded-full border border-white" />
                <div className="absolute -left-24 top-16 h-[275px] w-[275px] rounded-full border border-white" />
              </div>

              <div className="relative flex h-full flex-col justify-between">

                <div className="flex items-start justify-between">

                  <div className="text-right">

                    <h3 className="font-[var(--font-vazirmatn)] text-[24px] font-bold">
                      تمرین (بر اساس تخصص)
                    </h3>

                    <p className="mt-2 font-[var(--font-vazirmatn)] text-[13px] text-[#d7e0dc]">
                      حل کیس‌های طبقه‌بندی شده بر اساس هر تخصص
                    </p>

                  </div>

                  {/* PNG ONLY */}
                  <div className="flex h-[56px] w-[56px] items-center justify-center rounded-[13px] bg-white/10">
                    <img
                      src="/icons/courses/lungs.png"
                      alt=""
                      aria-hidden="true"
                      className="h-[32px] w-[32px] object-contain"
                      draggable={false}
                    />
                  </div>

                </div>

                <div className="mt-5 flex items-end justify-between">

                  {/* PNG specialties */}
                  <div className="flex flex-row-reverse gap-2">

                    {practiceSpecialties.map(
                      (item) => (
                        <span
                          key={item.key}
                          title={item.label}
                          className="
                            flex
                            h-[42px]
                            w-[42px]
                            items-center
                            justify-center
                            rounded-full
                            border
                            border-white/15
                            bg-white/[0.05]
                          "
                        >
                          <img
                            src={item.src}
                            alt=""
                            aria-hidden="true"
                            className="h-[22px] w-[22px] object-contain"
                            draggable={false}
                          />
                        </span>
                      ),
                    )}

                    <span
                      title="تخصص‌های بیشتر"
                      className="
                        flex
                        h-[42px]
                        w-[42px]
                        items-center
                        justify-center
                        rounded-full
                        border
                        border-white/15
                        bg-white/[0.05]
                        text-[16px]
                        tracking-widest
                      "
                    >
                      •••
                    </span>

                  </div>

                  {/* LEFT ARROW */}
                  <span
                    aria-hidden="true"
                    className="
                      flex
                      h-[50px]
                      w-[50px]
                      items-center
                      justify-center
                      rounded-full
                      bg-white
                      text-[#263e3b]
                      transition
                      group-hover:scale-105
                    "
                  >
                    <ArrowLeftIcon size={22} />
                  </span>

                </div>
              </div>
            </Link>

            {/* =================================================
                2 — CLINICAL REASONING
            ================================================== */}

            <Link
              href="/clinical-reasoning"
              className="
                group
                order-2
                min-h-[190px]
                flex-1
                rounded-[15px]
                border
                border-[#eee5d7]
                bg-[#faf6ef]
                p-6
                shadow-[0_5px_20px_rgba(15,23,42,0.025)]
                transition
                hover:-translate-y-[2px]
                hover:shadow-[0_10px_28px_rgba(133,99,46,0.055)]
              "
            >
              <div className="flex h-full flex-col justify-between">

                <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[#f3ebdf] text-[#8b7757]">
                  <Icon
                    name="bulb"
                    size={27}
                  />
                </div>

                <div className="mt-4 text-right">

                  <h3 className="font-[var(--font-vazirmatn)] text-[17px] font-bold text-[#162b3b]">
                    استدلال بالینی
                  </h3>

                  <p className="mt-2 font-[var(--font-vazirmatn)] text-[12px] leading-6 text-[#7d8a93]">
                    کیس‌های بدون اعلام تخصص
                    <br />
                    برای تقویت تفکر بالینی
                  </p>

                </div>

                <div className="flex justify-start">

                  <span
                    aria-hidden="true"
                    className="
                      flex
                      h-[44px]
                      w-[44px]
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-[#e1ddd4]
                      bg-white
                      text-[#2b414c]
                    "
                  >
                    <ArrowLeftIcon size={18} />
                  </span>

                </div>
              </div>
            </Link>

            {/* =================================================
                3 — EMERGENCY
            ================================================== */}

            <div
              className="
                group
                order-3
                min-h-[190px]
                flex-1
                rounded-[15px]
                border
                border-[#f0dfdf]
                bg-[#fbf1f1]
                p-6
                shadow-[0_5px_20px_rgba(15,23,42,0.025)]
                transition
                hover:-translate-y-[2px]
                hover:shadow-[0_10px_28px_rgba(160,70,70,0.055)]
              "
            >
              <div className="flex h-full flex-col justify-between">

                <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[#f8e7e7] text-[#c44747]">
                  <EmergencyIcon
                    size={27}
                  />
                </div>

                <div className="mt-4 text-right">

                  <h3 className="font-[var(--font-vazirmatn)] text-[17px] font-bold text-[#162b3b]">
                    اورژانس و شرایط حاد
                  </h3>

                  <p className="mt-2 font-[var(--font-vazirmatn)] text-[12px] leading-6 text-[#7d8a93]">
                    کیس‌های اورژانسی و
                    <br />
                    موقعیت‌های بحرانی
                  </p>

                </div>

                <div className="flex justify-start">

                  <span
                    aria-hidden="true"
                    className="
                      flex
                      h-[44px]
                      w-[44px]
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-[#e5d7d7]
                      bg-white
                      text-[#2b414c]
                    "
                  >
                    <ArrowLeftIcon size={18} />
                  </span>

                </div>

              </div>
            </div>

            {/* =================================================
                4 — DAILY ARCHIVE
            ================================================== */}

            <Link
              href="/case/today/archive"
              className="
                group
                order-4
                min-h-[190px]
                flex-1
                rounded-[15px]
                border
                border-[#e2e8ec]
                bg-[#f5f8fa]
                p-6
                shadow-[0_5px_20px_rgba(15,23,42,0.025)]
                transition
                hover:-translate-y-[2px]
                hover:shadow-[0_10px_28px_rgba(57,84,115,0.055)]
              "
            >
              <div className="flex h-full flex-col justify-between">

                <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[#eaf0f4] text-[#48697f]">
                  <Icon
                    name="calendar"
                    size={27}
                  />
                </div>

                <div className="mt-4 text-right">

                  <h3 className="font-[var(--font-vazirmatn)] text-[17px] font-bold text-[#162b3b]">
                    آرشیو کیس‌های روزانه
                  </h3>

                  <p className="mt-2 font-[var(--font-vazirmatn)] text-[12px] leading-6 text-[#7d8a93]">
                    دسترسی به تمام
                    <br />
                    کیس‌های منتشر شده
                  </p>

                </div>

                <div className="flex justify-start">

                  <span
                    aria-hidden="true"
                    className="
                      flex
                      h-[44px]
                      w-[44px]
                      items-center
                      justify-center
                      rounded-full
                      border
                      border-[#dfe5e8]
                      bg-white
                      text-[#2b414c]
                    "
                  >
                    <ArrowLeftIcon size={18} />
                  </span>

                </div>

              </div>
            </Link>

          </div>
        </section>

        {/* =================================================
            CONTINUE LEARNING
        ================================================== */}

        <section className="mt-5 overflow-hidden rounded-2xl border border-[#e7e4de] bg-white shadow-[0_5px_18px_rgba(15,23,42,0.025)]">

          <div className="border-b border-[#ece9e5] px-7 py-5">

            <div className="flex items-center justify-between">

              <span className="text-[13px] text-[#7b858c]">
                ادامه یادگیری
              </span>

              <h2 className="font-[var(--font-vazirmatn)] text-[22px] font-semibold text-[#22354e]">
                ادامه از جایی که ماندی
              </h2>

            </div>

          </div>

          <div className="divide-y divide-[#eceeec]">

            {continueCases.map(
              (item) => (
                <ContinueLearningRow
                  key={item.title}
                  item={item}
                />
              ),
            )}

          </div>
        </section>

        {/* =================================================
            PROGRESS
        ================================================== */}

        <section className="mt-5 rounded-2xl border border-[#e5e7e5] bg-white p-7">

          <div className="mb-7 flex items-center justify-between">

            <a
              href="#"
              className="flex items-center gap-2 font-[var(--font-vazirmatn)] text-[13px] text-[#52676c]"
            >
              مشاهده جزئیات
              <ArrowLeftIcon size={16} />
            </a>

            <div className="flex items-center gap-3">

              <Icon
                name="chart"
                size={24}
                className="text-[#718276]"
              />

              <h2 className="font-[var(--font-vazirmatn)] text-[23px] font-semibold text-[#22354e]">
                پیشرفت شما
              </h2>

            </div>

          </div>

          <div className="flex flex-col items-center gap-10 lg:flex-row">

            {/* CIRCLE */}
            <div className="relative flex h-[180px] w-[180px] shrink-0 items-center justify-center rounded-full border-[13px] border-[#e6e8e6]">

              <div className="absolute inset-[-13px] rotate-[25deg] rounded-full border-[13px] border-transparent border-r-[#294b45] border-t-[#294b45]" />

              <div className="text-center">

                <div className="font-[var(--font-vazirmatn)] text-[38px] font-black text-[#203449]">
                  ۱۸
                </div>

                <div className="mt-1 font-[var(--font-vazirmatn)] text-[12px] text-[#77848a]">
                  کیس حل شده
                </div>

              </div>
            </div>

            {/* BARS */}
            <div className="w-full space-y-6">

              {progress.map(
                (item) => (
                  <div
                    key={item.title}
                    className="flex items-center gap-4"
                  >

                    <span className="w-12 shrink-0 text-right font-[var(--font-vazirmatn)] text-[13px] text-[#596a74]">
                      {item.title}
                    </span>

                    <div className="h-[8px] flex-1 overflow-hidden rounded-full bg-[#e9eae8]">

                      <div
                        className="h-full rounded-full bg-[#294b45]"
                        style={{
                          width: `${item.value}%`,
                        }}
                      />

                    </div>

                    <span className="w-9 shrink-0 text-left font-[var(--font-vazirmatn)] text-[13px] text-[#485761]">
                      {item.value}٪
                    </span>

                  </div>
                ),
              )}

            </div>

          </div>
        </section>
      </div>
    </main>
  );
}

/* =========================================================
   CASE BADGE
========================================================= */

function CaseBadge({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <span
      className="
        rounded-full
        bg-[#f0f0ed]
        px-3.5
        py-1.5
        font-[var(--font-vazirmatn)]
        text-[11px]
        text-[#43505a]
      "
    >
      {children}
    </span>
  );
}

/* =========================================================
   CONTINUE LEARNING ROW
========================================================= */

function ContinueLearningRow({
  item,
}: {
  item: ContinueCaseData;
}) {
  return (
    <div className="grid items-center gap-5 px-7 py-5 lg:grid-cols-[80px_1fr_220px_95px]">

      {/* Icon */}
      <div className="flex h-[58px] w-[70px] items-center justify-center rounded-[10px] bg-[#eef2f1]">

        {item.type === "lungs" && (
          <img
            src="/icons/courses/lungs.png"
            alt=""
            aria-hidden="true"
            className="h-8 w-8 object-contain"
            draggable={false}
          />
        )}

        {item.type === "kidney" && (
          <img
            src="/icons/courses/kidney.png"
            alt=""
            aria-hidden="true"
            className="h-8 w-8 object-contain"
            draggable={false}
          />
        )}

        {item.type === "heart" && (
          <img
            src="/icons/courses/heart.png"
            alt=""
            aria-hidden="true"
            className="h-8 w-8 object-contain"
            draggable={false}
          />
        )}

      </div>

      {/* Text */}
      <div className="min-w-0 text-right">

        <h3 className="truncate font-[var(--font-vazirmatn)] text-[15px] font-semibold text-[#172d3e]">
          {item.title}
        </h3>

        <div className="mt-1 flex items-center gap-3 font-[var(--font-vazirmatn)] text-[11px] text-[#879198]">

          <span>
            {item.specialty}
          </span>

          <span>
            •
          </span>

          <span>
            {item.level}
          </span>

        </div>

      </div>

      {/* Progress */}
      <div className="flex items-center gap-3">

        <div className="h-[7px] flex-1 overflow-hidden rounded-full bg-[#e6e8e6]">

          <div
            className="h-full rounded-full bg-[#294b45]"
            style={{
              width: `${item.percent}%`,
            }}
          />

        </div>

        <span className="whitespace-nowrap font-[var(--font-vazirmatn)] text-[11px] text-[#647078]">
          {item.progress}
        </span>

      </div>

      {/* Continue */}
      <button
        type="button"
        className="
          flex
          h-[43px]
          w-[95px]
          items-center
          justify-center
          gap-2
          rounded-[9px]
          border
          border-[#e2e5e4]
          bg-white
          font-[var(--font-vazirmatn)]
          text-[12px]
          font-medium
          text-[#334750]
          transition
          hover:bg-[#f6f7f5]
        "
      >
        ادامه
        <ArrowLeftIcon size={16} />
      </button>

    </div>
  );
}

/* =========================================================
   GENERIC ICON
========================================================= */

function Icon({
  name,
  size = 24,
  strokeWidth = 1.8,
  className = "",
}: {
  name:
    | "search"
    | "calendar"
    | "document"
    | "bulb"
    | "lungs"
    | "target"
    | "bookmark"
    | "chart"
    | "trophy";
  size?: number;
  strokeWidth?: number;
  className?: string;
}) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className,
  };

  if (name === "search") {
    return (
      <svg {...common}>
        <circle
          cx="10.8"
          cy="10.8"
          r="6.2"
        />
        <path d="m15.5 15.5 4.2 4.2" />
      </svg>
    );
  }

  if (name === "calendar") {
    return (
      <svg {...common}>
        <rect
          x="3.5"
          y="5"
          width="17"
          height="15"
          rx="2"
        />
        <path d="M7 3v4M17 3v4M3.5 9.5h17" />
      </svg>
    );
  }

  if (name === "document") {
    return (
      <svg {...common}>
        <path d="M6 3.5h8l4 4V20.5H6z" />
        <path d="M14 3.5v4h4M9 12h6M9 15.5h6" />
      </svg>
    );
  }

  if (name === "bulb") {
    return (
      <svg {...common}>
        <path d="M8.5 14.5c-1.3-1.1-2.1-2.8-2.1-4.7A5.6 5.6 0 0 1 12 4.2a5.6 5.6 0 0 1 5.6 5.6c0 1.9-.8 3.6-2.1 4.7-.8.7-1.2 1.6-1.2 2.5H9.7c0-.9-.4-1.8-1.2-2.5Z" />
        <path d="M10 20h4M10.5 17h3" />
      </svg>
    );
  }

  if (name === "lungs") {
    return (
      <svg {...common}>
        <path d="M12 4v8" />
        <path d="M11 12c-2-3-4-5-5.5-4C4 9 3 14 4 18c.6 2.5 4 2 6-1v-5" />
        <path d="M13 12c2-3 4-5 5.5-4C20 9 21 14 20 18c-.6 2.5-4 2-6-1v-5" />
      </svg>
    );
  }

  if (name === "target") {
    return (
      <svg {...common}>
        <circle
          cx="12"
          cy="12"
          r="8"
        />
        <circle
          cx="12"
          cy="12"
          r="4"
        />
        <path d="m17.5 6.5 2-2M19 4.5h-2.5M19.5 4.5V7" />
      </svg>
    );
  }

  if (name === "bookmark") {
    return (
      <svg {...common}>
        <path d="M6 4.5A2.5 2.5 0 0 1 8.5 2h7A2.5 2.5 0 0 1 18 4.5V21l-6-3.5L6 21V4.5Z" />
      </svg>
    );
  }

  if (name === "chart") {
    return (
      <svg {...common}>
        <path d="M4 19V9M10 19V5M16 19v-7M22 19H2" />
      </svg>
    );
  }

  return (
    <svg {...common}>
      <path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" />
      <path d="M8 6H4v1a4 4 0 0 0 4 4M16 6h4v1a4 4 0 0 1-4 4M12 13v4M8 20h8M9 17h6" />
    </svg>
  );
}

/* =========================================================
   STETHOSCOPE
========================================================= */

function StethoscopeIcon({
  size = 24,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M6.5 4.5V9C6.5 12 8.4 14 11 14C13.6 14 15.5 12 15.5 9V4.5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <path
        d="M4.8 4.5H8.2"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="M13.8 4.5H17.2"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="M15.5 14V15.4C15.5 17.6 17.1 19.5 19.3 19.5C20.9 19.5 22 18.4 22 16.9C22 15.6 21.1 14.6 19.8 14.6"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/* =========================================================
   EMERGENCY ICON
========================================================= */

function EmergencyIcon({
  size = 24,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M12 4v3"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="M12 17v3"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="M4 12h3"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="M17 12h3"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="m6.3 6.3 2.1 2.1"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="m15.6 15.6 2.1 2.1"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="m17.7 6.3-2.1 2.1"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />

      <path
        d="m8.4 15.6-2.1 2.1"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

/* =========================================================
   ARROW LEFT
========================================================= */

function ArrowLeftIcon({
  size = 24,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M19 12H5"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />

      <path
        d="M11 6L5 12L11 18"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}